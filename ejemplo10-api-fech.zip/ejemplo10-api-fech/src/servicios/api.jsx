const BASE_URL = 'https://jsonplaceholder.typicode.com/users';

async function callApi(endpoint = '', options = {}){
    // Preparar las cabeceras sin sobreescribir las opciones anteriores
    const headers = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...options.headers
    };

    // Construir la url
    const url = `${BASE_URL}${endpoint}`;

    // Realizar la peticion
    const respuesta = await fetch(url, {
        ...options,
        headers
    });

    // Comprobar si la respuesta es correcta
    if (!respuesta.ok){
        throw new Error(`Ha ocurrido un error: ${respuesta.status} ${respuesta.statusText}`)
    }

    // retornar los datos
    return respuesta.json();
}

const api = {
    usuarios: {
        list() {
            return callApi();
        },

        create(usuario){
            return callApi('', {
                method: 'POST',
                body: JSON.stringify(usuario)
            });
        }
    }
};

export default api;