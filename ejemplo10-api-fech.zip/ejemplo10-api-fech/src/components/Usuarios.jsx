import { useEffect } from 'react';
import api from '../servicios/api';
import { useState } from 'react';

function Usuarios(){
    const [usuarios, setUsuarios] = useState([]);

    useEffect(() => {
        api.usuarios.list()
            .then(setUsuarios)
            .catch(error => console.error('Error al obtener usuarios:', error));
    }, []);

    return(
        <>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>EMAIL</th>
                        <th>WEBSITE</th>
                    </tr>
                </thead>
                <tbody>
                     {usuarios.map((item) => (
                        <tr key={item.id}>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.email}</td>
                            <td>{item.username}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    );
}

export default Usuarios;