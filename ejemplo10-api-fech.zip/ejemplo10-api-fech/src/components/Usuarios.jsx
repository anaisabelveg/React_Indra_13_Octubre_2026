import { useEffect } from 'react';
import api from '../servicios/api';
import { useState } from 'react';

function Usuarios(){
    const [usuarios, setUsuarios] = useState([]);

    useEffect(() => {
        api.usuarios.list()
            .then(datos => {
                setUsuarios(datos);
                console.log(datos);
            })
            .catch(error => console.error('Error al obtener usuarios:', error));
    }, []);

    return(
        <>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>EMAIL</th>
                        <th>CIUDAD</th>
                        <th>WEBSITE</th>
                    </tr>
                </thead>
                <tbody>
                     {usuarios.map((item) => (
                        <tr key={item.id}>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.email}</td>
                            <td>{item.address.city}</td>
                            <td>{item.website}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    );
}

export default Usuarios;