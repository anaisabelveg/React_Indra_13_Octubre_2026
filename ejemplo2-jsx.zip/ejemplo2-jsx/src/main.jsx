import { createRoot } from 'react-dom/client'

// Contenido JavaScript
/*
const contenedor = document.getElementById('root');
const elemento = document.createElement('h1');
elemento.innerText = 'Bienvenidos al curso de React !!';
contenedor.appendChild(elemento);
*/

// Ejemplo 1.- Contenido JSX
const jsx = <h1>Bienvenidos al curso de React !!</h1>;
const contenedor = document.getElementById('root');

// Para indicar donde mostramos el contenido
const root = createRoot(contenedor);

// Renderizar el contenido
root.render(jsx);


// Ejemplo 2.- Introducimos variables
const nombre = 'Anabel';
const jsx2 = <h1>Bienvenid@ {nombre} al curso de React !!</h1>;
root.render(jsx2);


// Ejemplo 3.- Resolver expresiones
const jsx3 = <p>Suma: 3 + 5 = {3+5}</p>;
root.render(jsx3);


// Ejemplo 4.- Invocar funciones
// funcion tradicional
/*function resta(n1, n2){
  return n1 - n2;
}*/

// funcion anonima con lambdas
const resta = (n1, n2) => {return n1 - n2;};
const jsx4 = <p>Resta: 5 - 3 = {resta(5,3)}</p>;
root.render(jsx4);


// Ejemplo 5.- Las expresiones que se resuelven como false, null, undefined
// React los ignora y no los renderiza
const jsx5 = <h1>Bienvenid@ {undefined} al curso de React !!</h1>;
root.render(jsx5);


// Ejemplo 6.- Renderizar mas de un elemento
const jsx6 = (
  <div>
    <h1>Bienvenid@ {nombre} al curso de React !!</h1>
    <a href="http://google.es" target='_blank'>Ir a Google</a>
  </div>
);
root.render(jsx6);

// mas simplificado:
root.render(
  <div>
    <h1>Bienvenid@@@@@ {nombre} al curso de React !!</h1>
    <a href="http://google.es" target='_blank'>Ir a Googleeeee</a>
  </div>
);