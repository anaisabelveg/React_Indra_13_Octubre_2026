// Para trabajar con el modulo de rutas hay que instalarlo:
// IMPORTANTE, desde dentro de la carpeta del proyecto
// npm i react-router-dom

import {BrowserRouter, Route, Routes} from 'react-router-dom';
import './App.css'
import Navbar from './components/Navbar'
import Componente1 from './components/Componente1';
import Componente2 from './components/Componente2';
import Componente3 from './components/Componente3';

function App() {
  
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path='/c1' element={ <Componente1 /> } />
        <Route path='/c2' element={ <Componente2 /> } />
        <Route path='/c3' element={ <Componente3 /> } />
      </Routes>

    </BrowserRouter>
  )
}

export default App
