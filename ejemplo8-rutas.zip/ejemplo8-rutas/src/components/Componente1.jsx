function Componente1(){
    return(
        <>
            <h1>Componente 1</h1>
        </>
    );
}

export default Componente1;