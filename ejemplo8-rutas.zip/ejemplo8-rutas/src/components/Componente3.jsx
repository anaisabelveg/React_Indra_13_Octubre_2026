function Componente3(){
    return(
        <>
            <h1>Componente 3</h1>
        </>
    );
}

export default Componente3;