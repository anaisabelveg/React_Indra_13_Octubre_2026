import { Link } from "react-router-dom";

function Navbar(){
    return (
        <>
            {/* Con Link se recarga solo el componente  */}
            <Link to="/c1"> Componente 1 </Link>
            <Link to="/c2"> Componente 2 </Link>
            <Link to="/c3"> Componente 3 </Link>
            
            {/* Con href se recarga la pagina entera  */}
            <a href="/c1"> Componente 1 con href</a>
        </>
    );
}

export default Navbar;