import './App.css'

function App() {
  
  return (
    <>
      <section id="center">
        <h1>Bienvenidos al curso de React !!</h1>
      </section>
    </>
  )
}

export default App
