import './App.css'

function App() {  
  return (
    <>
      <Mostrar logado={true} />
    </>
  )
}

// Componente que muestra el componente UsuarioRegistrado o UsuarioNoRegistrado
// Version 1.- if-else
/*function Mostrar(props) {
  if (props.logado){
    return <UsuarioRegistrado />
  } else {
    return <UsuarioNoRegistrado />
  }
}*/

// Version 2.- operador ternario.  condicion?true:false
/*function Mostrar(props) {
  return props.logado ? <UsuarioRegistrado /> : <UsuarioNoRegistrado />
}*/

// Version 3.- JSX con &&
function Mostrar( {logado} ){
  return(
    <>
      {!logado && <UsuarioNoRegistrado />}
      {logado &&<UsuarioRegistrado />}
    </>
  );
}

// Componente para los usuarios registrados
function UsuarioRegistrado() {
  return (
    <>
      <h1>Bienvenido a nuestra aplicacion</h1>
    </>
  )
}


// Componente para los usuarios no estan registrados
function UsuarioNoRegistrado() {
  return (
    <>
      <h1>Por favor, inicie sesion</h1>
    </>
  )
}


export default App
