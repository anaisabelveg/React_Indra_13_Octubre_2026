import { useTranslation } from 'react-i18next';

import './App.css';
import i18n from './services/i18n';

function App() {
  
  const { t } = useTranslation();

  const cambiarIdioma = (idioma) => {
    i18n.changeLanguage(idioma);
  };

  return (
    <>
      <div>
        <a onClick={() => cambiarIdioma('es')} >Español</a> |
        <a onClick={() => cambiarIdioma('en')} >Ingles</a>
      </div>

      <h1>{t("app.saludo")}</h1>

      <button>{t("app.boton")}</button>
    </>
  )
}

export default App
