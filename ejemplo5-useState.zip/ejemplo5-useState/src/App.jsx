import { useState } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)
  const [isSoltero, setIsSoltero] = useState(false)
  const [nombre, setNombre] = useState('')
  const [numeros, setNumeros] = useState([])

  const bucle = numeros.map((num, index) => (
    <li key={index}>{num}</li>
  ));

  return (  
    <>
      <p>Contador: {count}</p>
      { /* button*2 */ }
      <button onClick={ () => {
              setCount(count + 1);
              setNumeros([...numeros, count]);
            }}>
              Incrementar
      </button>
      <button onClick={ () => setCount(count - 1)}>Decrementar</button> <br/>

      <div className='fondo'
           onMouseOver={ () => setIsSoltero(true) }
           onMouseOut={ () => setIsSoltero(false)} >
          Estas soltero: {isSoltero ? 'Soltero' : 'Casado'}
      </div>
      
      <input type='text' 
        value={nombre} 
        onChange={ event => {
          console.log(event.target.value);
          setNombre(event.target.value)
        }} />
      <p>Tu nombre es: {nombre} </p>

      <ul>
        {bucle}
      </ul>
      
      {numeros.join(" ")}
    </>
  )
}

export default App
