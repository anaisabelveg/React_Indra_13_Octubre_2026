import './styles/Footer.css';
import { useTranslation } from 'react-i18next';

function Footer(){
    
    const { t } = useTranslation();

    return(
        <>
            <p id="pie">{t("footer.pie_pagina", { nombre: "Anabel" })}</p>
        </>
    );
}

export default Footer;