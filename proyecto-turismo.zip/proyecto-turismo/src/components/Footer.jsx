import './styles/Footer.css';

function Footer(){
    return(
        <>
            <p id="pie">Sitio web realizado por: Anabel</p>
        </>
    );
}

export default Footer;