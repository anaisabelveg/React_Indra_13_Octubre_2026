import './styles/Footer.css';

function Footer(){
    return(
        <>
            <p>Sitio web realizado por: Anabel</p>
        </>
    );
}

export default Footer;