import museosService from "../servicios/museosService";
import { Link } from 'react-router-dom';
import './styles/Museos.css';

function Museos(){
    const museos = museosService.museos;
    console.log(museos);

    return(
        <ul className="lista-museos list-unstyled mb-0">
            {museos.map( (museo) => (
                <li key={museo.id} className="museo-item">
                    <Link to={`/detalle/${museo.id}`} className="nombre-item"> 
                        {museo.nombre}     
                    </Link>
                </li>
            ))}
        </ul>
    );
}

export default Museos;