function Museos(){
    return(
        <>
            <p>Museos</p>
        </>
    );
}

export default Museos;