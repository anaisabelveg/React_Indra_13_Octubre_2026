import { useEffect } from 'react';
import api from '../servicios/api';
import { useState } from 'react';
import './styles/Equipo.css';

function Equipo(){

    const [miembros, setMiembros] = useState([]);

    useEffect(() => {
        api.personajes.list()
            .then(datos => {
                setMiembros(datos.results);
                console.log(datos);
            })
            .catch(error => console.error('Error al obtener personajes:', error));
    }, []);

    return(
        <div className='row' id="equipo">
            {miembros.map((item) => (
                <div className='col-3' id="tarjeta">
                    <div className="card">
                        <img src={item.image} className="card-img-top" alt={item.name} />
                        <div className="card-body">
                            <h5 className="card-title">{item.name}</h5>
                            <p className="card-text">{item.status}</p>
                            <p className="card-text">{item.species}</p>
                        </div>
                    </div>
                </div>
            ))}        
        </div>
    );
}

export default Equipo;
