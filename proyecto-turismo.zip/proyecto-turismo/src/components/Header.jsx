import { useTranslation } from 'react-i18next';
import i18n from '../servicios/i18n';

import logo from '../assets/logo.png';
import spain from '../assets/banderas/spain.png';
import inglaterra from '../assets/banderas/inglaterra.png';
import francia from '../assets/banderas/francia.png';
import alemania from '../assets/banderas/alemania.png';
import './styles/Header.css';

function Header(){
    const { t } = useTranslation();
    
    const cambiarIdioma = (idioma) => {
        i18n.changeLanguage(idioma);
    };

    return(
        <>
            <img className='logo' src={logo} />
            <h1 className='titulo'>{t("header.titulo")}</h1>

            <span id="banderas">
                <img className='imagen' onClick={() => cambiarIdioma('es')} src={spain}  />
                <img className='imagen' onClick={() => cambiarIdioma('en')} src={inglaterra} />
                <img className='imagen' onClick={() => cambiarIdioma('fr')} src={francia} />
                <img className='imagen' onClick={() => cambiarIdioma('de')} src={alemania} />
            </span>
        </>
    );
}

export default Header;