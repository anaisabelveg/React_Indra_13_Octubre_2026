import logo from '../assets/logo.png';
import './styles/Header.css';

function Header(){
    return(
        <>
            <img src={logo} />
            <h1>Turismo por Madrid</h1>
        </>
    );
}

export default Header;