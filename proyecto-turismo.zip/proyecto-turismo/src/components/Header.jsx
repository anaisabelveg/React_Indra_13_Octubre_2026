import logo from '../assets/logo.png';
import './styles/Header.css';

function Header(){
    return(
        <>
            <img className='logo' src={logo} />
            <h1 className='titulo'>Turismo por Madrid</h1>
        </>
    );
}

export default Header;