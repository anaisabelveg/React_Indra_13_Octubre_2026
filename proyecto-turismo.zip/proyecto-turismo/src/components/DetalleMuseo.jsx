import {useParams} from 'react-router-dom';
import museosService from "../servicios/museosService";

function DetalleMuseo(){
    // Recoger el parametro id
    const {id} = useParams();

    // Buscar el museo con ese id
    const museo = museosService.buscarMuseo(id);

    return(
        <div className='row' style={{margin: '20px'}}>
            <div className='col-3'></div>
            <div className='col-6'>
                <div className="card">
                    <img src={museo.imagen} className="card-img-top" alt={museo.nombre} />
                    <div className="card-body">
                        <h5 className="card-title">{museo.nombre}</h5>
                        <p className="card-text">{museo.direccion}</p>
                    </div>
                    <ul className="list-group list-group-flush">
                        <li className="list-group-item">Telefono: {museo.telefono}</li>
                        <li className="list-group-item">Horario: {museo.horario}</li>
                        <li className="list-group-item">Precio: {museo.precio}</li>
                    </ul>
                    <div className="card-body">
                        <a href={museo.web} target='_blank' className="card-link">Web del museo</a>
                        <a href={`https://www.google.com/maps/place/${museo.coordenadas}`} 
                            target='_blank' className="card-link">Mostrar ubicacion</a>
                    </div>
                </div>
            </div>
            <div className='col-3'></div>
        </div>
    );
}

export default DetalleMuseo;