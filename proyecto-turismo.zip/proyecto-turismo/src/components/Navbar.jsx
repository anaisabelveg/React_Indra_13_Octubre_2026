import { Link } from "react-router-dom";
import { useTranslation } from 'react-i18next';

function Navbar(){

    const { t } = useTranslation();

    return(
        <>
            <nav className="navbar navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
                <div className="container-fluid">
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <Link className="nav-link" to="/home">{t("navbar.home")}</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/museos">{t("navbar.museos")}</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/equipo">{t("navbar.equipo")}</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/contacto" >{t("navbar.contacto")}</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </>
    );
}

export default Navbar;