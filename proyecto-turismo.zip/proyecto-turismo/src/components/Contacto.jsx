import { useState } from 'react'
import './styles/Contacto.css'

function Contacto(){
    const [form, setForm] = useState({
        nombre: '',
        telefono: '',
        email: '',
        asunto: '',
        mensaje: ''
    });

    const [errores, setErrores] = useState({});

    const handleChange = (e) => {
        const {name, value} = e.target;

        setForm( (datosPrevios) => ({
            ...datosPrevios,
            [name]: value
        }) );
    };

    const validar = (e) => {
        // Cancelar el evento submit, no enviamos los datos
        e.preventDefault();

        const mensajesError = {};

        // Validar nombre
        if (!form.nombre.trim()){
            mensajesError.nombre = 'Nombre obligatorio';
        } else if (form.nombre.length < 3){
            mensajesError.nombre = 'Minimo 3 caracteres';
        }

        // Validar telefono
        if (form.telefono === ''){
            mensajesError.telefono = 'Telefono obligatorio';
        } else if (!/^[6,7,9]{1}[0-9]{8}$/.test(form.telefono) ){
            mensajesError.telefono = 'Debe tener 9 digitos y comenzar por 6,7 ó 9';
        }

        // Validar email
        if (!form.email.trim()){
            mensajesError.email = 'Email obligatorio';
        } else if (!/\S+@\S+\.\S+/.test(form.email)){
            mensajesError.email = 'El formato del e-mail no es correcto';
        }

        // Validar asunto
        if (!form.asunto.trim()){
            mensajesError.asunto = 'Asunto obligatorio';
        } else if (form.asunto.length < 5){
            mensajesError.asunto = 'Minimo 5 caracteres';
        } 

        // Validar mensaje
        if (!form.mensaje.trim()){
            mensajesError.mensaje = 'Mensaje obligatorio';
        } else if (form.mensaje.length < 10){
            mensajesError.mensaje = 'Minimo 10 caracteres';
        } 

        // Guardo los mensajes en el estado
        setErrores(mensajesError);

        if (Object.keys(mensajesError).length === 0){
        alert('Formulario valido');
        }
    };

    return(
        <div className='row'>
            <div className='col-3'></div>
            <div id="panel" className="card border-0 shadow-sm rounded-4 col-6">
                <form onSubmit={validar} noValidate>
                    <div className="mb-3">
                        <label htmlFor="nombre" className="form-label fw-semibold">Nombre:</label>
                        <input type='text'
                            className="form-control form-control-lg rounded-3"
                            id='nombre' 
                            name='nombre' 
                            value={form.nombre} 
                            onChange={handleChange}/>
                        <span className='error'>
                            {errores.nombre}
                        </span>
                    </div>

                    <div className="mb-3">
                        <label htmlFor="telefono" className="form-label fw-semibold">Telefono:</label>
                        <input type='text'
                            className="form-control form-control-lg rounded-3"
                            id='telefono' 
                            name='telefono' 
                            value={form.telefono} 
                            onChange={handleChange}/>
                        <span className='error'>
                            {errores.telefono}
                        </span>
                    </div>

                    <div className="mb-3">
                        <label htmlFor="email" className="form-label fw-semibold">Email:</label>
                        <input type='email'
                            className="form-control form-control-lg rounded-3"
                            id='email' 
                            name='email' 
                            value={form.email} 
                            onChange={handleChange}/>
                        <span className='error'>
                            {errores.email}
                        </span>
                    </div>

                    <div className="mb-3">
                        <label htmlFor="asunto" className="form-label fw-semibold">Asunto:</label>
                        <input type='text'
                            className="form-control form-control-lg rounded-3"
                            id='asunto' 
                            name='asunto' 
                            value={form.asunto} 
                            onChange={handleChange}/>
                        <span className='error'>
                            {errores.asunto}
                        </span>
                    </div>

                    <div className="mb-3">
                        <label htmlFor="mensaje" className="form-label fw-semibold">Mensaje:</label>
                        <textarea rows={5}
                            className="form-control form-control-lg rounded-3"
                            id='mensaje' 
                            name='mensaje' 
                            value={form.mensaje} 
                            onChange={handleChange}></textarea>
                        <span className='error'>
                            {errores.mensaje}
                        </span>
                    </div>

                    <button type='submit'
                        className="btn btn-dark btn-lg w-100 rounded-3">Enviar</button>
                </form>
            </div>
            <div className='col-3'></div>
        </div>
    );
}

export default Contacto;
