import { useState } from 'react'
import './styles/Contacto.css'

function Contacto(){
    const [form, setForm] = useState({
        nombre: '',
        telefono: '',
        email: '',
        asunto: '',
        mensaje: ''
    });

    const [errores, setErrores] = useState({});

    const handleChange = (e) => {
        const {name, value} = e.target;

        setForm( (datosPrevios) => ({
            ...datosPrevios,
            [name]: value
        }) );
    };

    const validar = (e) => {
        // Cancelar el evento submit, no enviamos los datos
        e.preventDefault();

        const mensajesError = {};

        // Validar nombre
        if (!form.nombre.trim()){
            mensajesError.nombre = 'Nombre obligatorio';
        } else if (form.nombre.length < 3){
            mensajesError.nombre = 'Minimo 3 caracteres';
        }

        // Validar telefono
        if (form.telefono === ''){
            mensajesError.telefono = 'Telefono obligatorio';
        } else if (!/^[6,7,9]{1}[0-9]{8}$/.test(form.telefono) ){
            mensajesError.telefono = 'Debe tener 9 digitos y comenzar por 6,7 ó 9';
        }

        // Validar email
        if (!form.email.trim()){
            mensajesError.email = 'Email obligatorio';
        } else if (!/\S+@\S+\.\S+/.test(form.email)){
            mensajesError.email = 'El formato del e-mail no es correcto';
        }

        // Validar asunto
        if (!form.asunto.trim()){
            mensajesError.asunto = 'Asunto obligatorio';
        } else if (form.asunto.length < 5){
            mensajesError.asunto = 'Minimo 5 caracteres';
        } 

        // Validar mensaje
        if (!form.mensaje.trim()){
            mensajesError.mensaje = 'Mensaje obligatorio';
        } else if (form.mensaje.length < 10){
            mensajesError.mensaje = 'Minimo 10 caracteres';
        } 

        // Guardo los mensajes en el estado
        setErrores(mensajesError);

        if (Object.keys(mensajesError).length === 0){
        alert('Formulario valido');
        }
    };

    return(
        <>
            <form onSubmit={validar} noValidate>
                <div>
                    <label htmlFor="nombre">Nombre:</label>
                    <input type='text'
                        id='nombre' 
                        name='nombre' 
                        value={form.nombre} 
                        onChange={handleChange}/>
                    <span className='error'>
                        {errores.nombre}
                    </span>
                </div>

                <div>
                    <label htmlFor="telefono">Telefono:</label>
                    <input type='text'
                        id='telefono' 
                        name='telefono' 
                        value={form.telefono} 
                        onChange={handleChange}/>
                    <span className='error'>
                        {errores.telefono}
                    </span>
                </div>

                <div>
                    <label htmlFor="email">Email:</label>
                    <input type='email'
                        id='email' 
                        name='email' 
                        value={form.email} 
                        onChange={handleChange}/>
                    <span className='error'>
                        {errores.email}
                    </span>
                </div>

                <div>
                    <label htmlFor="asunto">Asunto:</label>
                    <input type='text'
                        id='asunto' 
                        name='asunto' 
                        value={form.asunto} 
                        onChange={handleChange}/>
                    <span className='error'>
                        {errores.asunto}
                    </span>
                </div>

                <div>
                    <label htmlFor="mensaje">Mensaje:</label>
                    <textarea rows={5}
                        id='mensaje' 
                        name='mensaje' 
                        value={form.mensaje} 
                        onChange={handleChange}></textarea>
                    <span className='error'>
                        {errores.mensaje}
                    </span>
                </div>

                <button type='submit'>Enviar</button>
            </form>
        </>
    );
}

export default Contacto;
