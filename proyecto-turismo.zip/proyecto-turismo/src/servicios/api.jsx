async function callApi(){
    // Preparar las cabeceras sin sobreescribir las opciones anteriores
    const headers = {
        'Content-Type': 'application/json',
        Accept: 'application/json'
    };

    // Construir la url
    const url = 'https://rickandmortyapi.com/api/character';

    // Realizar la peticion
    const respuesta = await fetch(url, {headers});

    // Comprobar si la respuesta es correcta
    if (!respuesta.ok){
        throw new Error(`Ha ocurrido un error: ${respuesta.status} ${respuesta.statusText}`)
    }

    // retornar los datos
    return respuesta.json();
}

const api = {
    personajes: {
        list() {
            return callApi();
        }
    }
};

export default api;