import './App.css'
import Home from './components/Home';
import Footer from './components/Footer'
import Header from './components/Header'
import Navbar from './components/Navbar'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Museos from './components/Museos';
import Equipo from './components/Equipo';
import Contacto from './components/Contacto';


function App() {
  
  return (
    <>
      <header>
        <Header />
      </header>

      <BrowserRouter>
          <nav>
            <Navbar />
          </nav>

          <section>
            <Routes>
              <Route path='/home' element={<Home />} />
              <Route path='/museos' element={<Museos />} />
              <Route path='/equipo' element={<Equipo />} />
              <Route path='/contacto' element={<Contacto />} />
            </Routes>
          </section>
      </BrowserRouter>
      
      <footer>
        <Footer />
      </footer>
    
    </>
  )
}

export default App
