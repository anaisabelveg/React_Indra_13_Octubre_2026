import './App.css'
import Footer from './components/Footer'
import Header from './components/Header'
import Navbar from './components/Navbar'

function App() {
  
  return (
    <>
      <header>
        <Header />
      </header>

      <nav>
        <Navbar />
      </nav>

      <section>
        contenido
      </section>

      <footer>
        <Footer />
      </footer>
    </>
  )
}

export default App
