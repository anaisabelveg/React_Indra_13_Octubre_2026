import './App.css'
import Producto from './components/Producto'

function App() {
  
  const atributos = {
      nombre: 'Impresora',
      descripcion: 'Multifuncion a color y scanner',
      precio: 129.95,
      fabricante: 'Brother'
  };

  return (
    <>
      <section id="center">
        <Producto {...atributos} />
        <Producto 
          nombre = "Pantalla"
          descripcion = "17 pulgadas"
          precio = "200"
          fabricante = "LG"  />
      </section>
    </>
  )
}

export default App
