import './Producto.css';

function Producto(props){
    return (
        <div id="panel">
            <h1>Detalle del producto</h1>
            <h2>Nombre: {props.nombre}</h2>
            <h2>Descripcion: {props.descripcion}</h2>
            <h2>Precio: {props.precio}</h2>
            <h2>Fabricante: {props.fabricante}</h2>
        </div>
    )
}

export default Producto