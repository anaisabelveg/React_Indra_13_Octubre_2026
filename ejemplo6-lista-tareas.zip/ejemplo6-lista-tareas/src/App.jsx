import { useState } from 'react'
import './App.css'
import Formulario from './components/Formulario'
import Lista from './components/Lista'

function App() {
  const [tareas, setTareas] = useState([])

  const agregarTarea = (texto) => {
    setTareas( tareas => [ ...tareas, texto] )
  }

  return (
    <>
      <Formulario onSubmit={agregarTarea} />
      <Lista coleccion={tareas} />
    </>
  )
}

export default App
