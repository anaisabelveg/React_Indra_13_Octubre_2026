function Lista( {coleccion} ){

    const bucle = coleccion.map( (tarea, index) => (
       <li key={index}> {tarea} </li> 
    ) );

    return (
        <>
            <ol>
                {bucle}
            </ol>
        </>
    )
}

export default Lista