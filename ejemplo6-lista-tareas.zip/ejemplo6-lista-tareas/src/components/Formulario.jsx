import { useState } from "react";

function Formulario( {onSubmit} ){
    const [texto, setTexto] = useState('');


    const enviarTarea = (event) => {
        // Cancela el evento submit
        event.preventDefault();

        // Envio el tarea al componente App
        onSubmit(texto);

        // Limpiar el formulario
        setTexto('');
    }

    return (
        <>
            <form onSubmit = {enviarTarea}>
                <label>Tarea:</label>
                <input type="text"
                        value={texto} 
                        onChange={e => setTexto(e.target.value) }/>
                <input type="submit" value="Agregar tarea" />
            </form>
        </>
    )
}

export default Formulario