import './App.css'

function App() {

  // Manejador de eventos
  const handleMouseOver = () => {
    alert("Estas dentro del div");
  };

  return (
    <>
      <div className='fondo'
        onMouseOver={handleMouseOver}
        onMouseOut={ () => alert("Estas fuera del div") }>
      </div>

      <button onClick={() => alert("Boton pulsado")}>Pulsame</button> <br/>

      <p onCopy={ () => {
                const texto = window.getSelection()?.toString() ?? '';
                alert(texto)
            }}
         onPaste={ () => alert("Texto pegado")}
         onCut={ () => alert("Texto cortado")}>
        Este texto es para probar los eventos
      </p>
    </>
  )
}

export default App
